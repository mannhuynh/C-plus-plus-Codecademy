using namespace std;

string reverse_word(string sentence);

void fizzbuzz();

bool is_palindrome(std::string text);
